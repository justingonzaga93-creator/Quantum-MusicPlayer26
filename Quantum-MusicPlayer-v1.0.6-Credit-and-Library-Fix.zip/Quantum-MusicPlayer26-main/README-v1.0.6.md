# Quantum Music Player v1.0.6 (source update)

## Included
- Live frequency visualizer using Web Audio API when supported
- Favorites filter and named playlists (playlist membership saved locally)
- Sleep timer
- Bass and treble filters where supported by Web Audio API
- Four saved themes and animated cover effects
- Media Session metadata and headset/lock-screen action handlers where supported by browser/OS
- Duplicate-file skipping when the same local file is selected again
- PWA manifest and service worker for offline app-shell caching when served over HTTPS/localhost

## Test locally
1. Extract the ZIP.
2. Serve this folder with a local static web server (for example, `python -m http.server 8000`).
3. Open `http://localhost:8000` in a modern browser.
4. Add local audio files with **Add songs**, then test playback, favorites, playlists, visualizer, themes, equalizer, and sleep timer.

Opening `index.html` directly also allows basic testing, but service-worker installation and PWA features require localhost or HTTPS.

## Android build status
This repository is a plain HTML/CSS/JavaScript web app; it does not include an Android Gradle project or Capacitor/Cordova wrapper. This source update is **not an APK**. Media Session and background playback behavior depend on the browser/WebView and Android lifecycle; reliable background playback/lock-screen controls require testing inside an Android wrapper, and may require native media-session/service integration.

To produce an installable APK, wrap this web app with Capacitor (or a native Android WebView project), add native media-session/background playback integration, then build and test on a physical Android device. Do not consider an APK ready until playback, permissions, screen-off behavior, and Android back/navigation have been tested.


## v1.0.6 persistence and creator-credit fix
- Creator credit button is now placed near the top under the header.
- Initial music-library restoration completes before a newly selected batch is saved.
- Save errors are surfaced instead of claiming files were saved when IndexedDB failed.
- Library data is stored by the browser origin. Reopening this app from a different file path,
  browser, WebView/app wrapper, private session, or after clearing site data may show an empty
  library. In that case, select the music files again; browsers do not let this web app recover
  files from a different origin automatically.
- Test using the same browser and same hosted address each time (localhost or HTTPS is preferred).
